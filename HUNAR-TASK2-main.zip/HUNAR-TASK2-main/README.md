# HUNAR-TASK2
def caesar_encrypt(text, shift):
    encrypted = ""
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            encrypted += chr((ord(char) - base + shift) % 26 + base)
        else:
            encrypted += char
    return encrypted

def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)

def main():
    print("Caesar Cipher Encryption/Decryption Tool")
    choice = input("Type 'E' to Encrypt or 'D' to Decrypt: ").upper()
    message = input("Enter your message: ")
    shift = int(input("Enter shift key (e.g., 3): "))

    if choice == 'E':
        result = caesar_encrypt(message, shift)
        print(f"\n Encrypted Message: {result}")
    elif choice == 'D':
        result = caesar_decrypt(message, shift)
        print(f"\n Decrypted Message: {result}")
    else:
        print(" Invalid choice. Please select 'E' or 'D'.")

if __name__ == "__main__":
    main()

